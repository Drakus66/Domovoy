# Domovoy System — Current State Summary
**Last Updated**: 2026-07-19
**Branch analyzed**: `epic-3b-scenes` (= `develop` tip, 0 own commits) + большой незакоммиченный рабочий diff поверх него

> Авторитетный снимок текущего состояния кода. Точка входа и навигация — [README.md](README.md);
> дорожная карта — [`../docs/architecture/roadmap.md`](../docs/architecture/roadmap.md); текущий фокус —
> [activeContext.md](activeContext.md).

> ⚠️ **Коммит-статус (перепроверено 2026-07-19):** последний коммит в репозитории — `85e2917` (merge
> `epic-dashboard-fill` → `develop`, 2026-07-17, включает `19c8b44` «Fix Automations»). Всё, что описано
> ниже как относящееся к **Фазе 3 (3A/3B)**, к **редизайну `/automations`** (удаление `/flow`), к **хвостам
> 2Q** (PID-автотюн) и к **system-restart**, физически лежит только в рабочем дереве — **не закоммичено**.
> Раздел ниже описывает код **как он есть на диске сейчас** (это и есть «текущее состояние»), но каждый
> такой блок помечен явно, чтобы не путать с зафиксированной историей. Подробности — [activeContext.md](activeContext.md).

## Executive Summary
Domovoy — .NET 9 умный дом на RabbitMQ + MongoDB. Архитектура — событийная (capability-контракт на шине),
4 backend-сервиса + 2 шлюза + WebUI. **Фазы 0/1/1.5/2 закрыты** (все эпики 1A–1H и 2A–2Q v1-done,
Фаза 1.5 — живой 3-оконный прогон подтверждён). Продукт умеет: типизировать устройства, находить
закономерности и предлагать правила/ML-задачи (очередь апрува), обучать ML.NET-модели как control-blocks
(стадии Shadow→Bounded→Full), вести «Дневник дома» (детерминированный NLG), геолокацию/календарь/вирт.
сенсоры Sun-Time-Calendar, роли (без enforcement), плагины (in-proc supervisor, 1 живой плагин — Commute),
адаптеры Zigbee2MQTT/ESPHome/Domovoy Native. **Сейчас в работе (Фаза 3, НЕ закоммичено):** бэкапы/восстановление
(3A), сцены как first-class объект (3B), плюс попутные незакоммиченные правки — редизайн `/automations`
(Flow-редактор удалён), system-restart из UI, прошивки `Arduino/house/`.

## Архитектура (актуальная)

### Backend-сервисы (4)
- **Domovoy.UnifiedDeviceService** — `CapabilityDeviceManager` (`BackgroundService`): подписан на
  `Envelope<DeviceDiscoveredV1>`/`Envelope<DeviceStateReportV1>`, in-memory capability-реестр →
  переизлучение в SignalR.
- **Domovoy.Connectivity** — `AdapterManager` (один MQTT-клиент), маршрутизация по
  `IProtocolAdapter.CanHandleTopic`. Адаптеры: **Zigbee2MqttAdapter** (`exposes`→capability, per-device
  codec), **DomovoyNativeAdapter** (capability-native, Last-Will+heartbeat+staleness watchdog),
  **EspHomeMqttAdapter** (Epic 2J — HA MQTT Discovery→capability, работает и на ESP32/ESP8266).
- **Domovoy.AutomationService** — детерминированный движок правил `trigger→condition→action` (1A) +
  cron/sun-планировщик + безопасный пол (`safety-rules.json`); **control blocks** (1H/1D/2Q — 25+
  примитивов: hysteresis/PID/expression/time-state + композиты/шаблоны + DSL-опции, `block_state`
  персистентность); **реплей/Shadow** (1F); **режимы дома** (1G, `presence_mode`-блок вместо удалённого
  `PresenceMonitor`); **ML** (2A/2B/2I/2P — реестр ML.NET-моделей, multi-target `ml_tasks`, governor-блоки
  с дрифт-мониторингом); **Discovery Engine** (2F — MI/χ²/BH-FDR pattern-mining → предложения); **Дневник
  дома** (2N, `DiaryMiner`→`SceneBuilder`→`SignificanceScorer`→`DayConsolidator`→NLG); **Assistant-заглушка**
  (2H, `IAssistantConnector` — provider-agnostic, no-op по умолчанию). **[НЕ закоммичено]** новое
  действие правил `scene` (3B, резолв через `SceneStore`); **[НЕ закоммичено]** PID-автотюн
  Åström–Hägglund (2Q-хвост, `PidAutotune.cs`).
- **Domovoy.PluginSupervisor** — манифест-based супервизор внепроцессных плагинов (resource-gating
  cpu/ram/gpu/internet), рестарт с backoff. Один живой плагин — **Commute** (Epic 2M.1, traffic-aware
  ETA, `ITrafficProvider` offline sim / TomTom). Также хостит **Реплей/Shadow** эндпоинт (`POST /api/replay`).

### Шлюзы (2)
- **Domovoy.DbGateway** — Minimal-API + MongoDB, единственный сервис с прямым доступом к Mongo (кроме
  Serilog-sink `ops_logs` из всех сервисов). 26 файлов/~253 точки использования `IMongoDatabase`, без
  repository-слоя (см. план абстракции хранилища, Эпик 3H). Эндпоинты сгруппированы в
  `src/Gateway/Domovoy.DbGateway/Endpoints/`: `CapabilityDeviceEndpoints`, `ZoneEndpoints`,
  `HistoryEndpoints` (телеметрия+event-log+агрегации, самый тяжёлый), `AutomationEndpoints`,
  `BlockEndpoints`/`BlockStateEndpoints`, `ModeEndpoints`, `MlEndpoints`/`MlTaskEndpoints`,
  `ActivityEndpoints`, `RolesEndpoints`/`UsersEndpoints`, `ProposalsEndpoints`, `DashboardEndpoints`,
  `SettingsEndpoints` (геолокация+календарь), `NarrativeEntityEndpoints`/`HomeStoryEndpoints` (2N),
  `SceneEndpoints` **[НЕ закоммичено, 3B]**, `BackupEndpoints` **[НЕ закоммичено, 3A]**.
  `EventInterceptor` — сердце feature store: capability-контракт+команды → upsert `capability_devices` +
  append-only `device_events`/`sensor_readings` (Mongo time-series) + block-run-records → `block_history`.
- **Domovoy.ApiGateway** — endpoint-routing (без Ocelot) + Swagger + Prometheus `/metrics` + SignalR-хаб
  `/hub/devices`. Контроллеры (`src/Gateway/Domovoy.ApiGateway/Controllers/`) — тонкие прокси к DbGateway
  либо publish на шину: `CapabilityDevicesController`, `DeviceControlController`, `ZonesController`,
  `ModeController`, `HistoryController`, `ReplayController`, `BlocksController`, `PluginsController`,
  `MlController`, `RolesController`/`UsersController`, `ProposalsController`, `DashboardsController`,
  `SettingsController`, `HomeStoryController`, `AssistantController`, `ZigbeeController`,
  `MetricsController`/`StatusController`. **[НЕ закоммичено]** `ScenesController` (3B), `BackupController`
  (3A), `SystemController`+`ContainerControl.cs` (self-restart по шине + опц. docker.sock контроль).

### Контракт (1)
- **Domovoy.Contracts** (zero deps) — `Envelope<T>` (CloudEvents 1.0), открытая capability-модель,
  `DeviceDescriptor`/`DeviceIdentity`/`DeviceIdFactory` (RFC-4122 v5), `BusTopology`, `MessageTypes`,
  payload-контракты, `Automations/`, `Blocks/` (+ `CompositeParam`), `Home/`, `Ml/`, `Plugins/`,
  `Security/` (2E), `Narrative/` (2N), `Devices/DeviceArchetypes` (2D), `NativeProtocol`.
  **[НЕ закоммичено]** `Scenes/` (3B — `Scene`, `SceneTarget`).

### Общие библиотеки
- **Domovoy.Common** — `BaseCommand`/`BaseEvent`, `DeviceStateUpdatedEvent` (SignalR-релей),
  `ZigbeeBridge*`, `MessageBusConfiguration`, Serilog bootstrap (`SerilogBootstrap`, capped Mongo-sink
  `ops_logs`, pin `Serilog.Sinks.MongoDB` 5.4).
- **Domovoy.MessageBus** — `IMessageBus` + `RabbitMqConnection` (ленивая декларация exchange, retry/backoff,
  DLQ `domovoy.dlx`). **[НЕ закоммичено]** `SystemControl.cs` (`SystemControlListener` + `AddSystemControl`
  extension — self-restart по broadcast-команде через шину).
- **Domovoy.Narrative** (2N) — язык-нейтральный IR (`Beat`/`Scene`/`DayStory`), `INarrativeRenderer`,
  встроенный `RuLanguagePackRenderer` (данные, не код — `Packs/ru.json`).

### Tools / UI / Hardware
- **Domovoy.DeviceEmulator** — ASP.NET Web + UI (`:5080`), реф-реализация Domovoy Native v1, локальный
  dev-инструмент (не в docker).
- **WebUI** — React + Vite + MUI 5. Текущие страницы (`src/pages/`): `Devices.tsx` (индекс `/` —
  вкладки: Все + авто-сферы по архетипам + свои дашборды, `HomeStateBand`+`DomovoyRail`+обогащённые
  плитки со спарклайном — Epic dashboard-fill), `DeviceRegistry.tsx` (`/devices` — плоский реестр-таблица
  всех устройств с поиском/удалением, отдельно от домашнего экрана), `Zones.tsx`, `Modes.tsx`,
  `Automations.tsx` (мульти-триггер/условие/действие + редактирование, конструктор+история+Simulate+Shadow),
  `Blocks.tsx` (control blocks, category-picker, граф-редактор), `Plugins.tsx`, `Models.tsx` (хаб ML —
  задачи/применения), `Proposals.tsx` (очередь апрува), `Users.tsx` (роли/пользователи), `ZigbeeDevices.tsx`
  (bridge-mgmt), `Settings.tsx` (геолокация+календарь; **[НЕ закоммичено]** + бэкапы 3A), `Logs.tsx`
  (Activity center + тумблер «Дневник дома»), `SystemStatus.tsx` (метрики; **[НЕ закоммичено]**
  `SystemControlCard`), `NotFound.tsx`. **[НЕ закоммичено]** `Scenes.tsx` (3B — список/активация/Re-Capture).
  **[Удалено, но НЕ закоммичено — физически ещё в HEAD]** `Flow.tsx` (React Flow редактор правил, признан
  дублем `/automations`).
- **Arduino** — `DomovoyClient` **[НЕ закоммичено: header-only 2.2.0]**, мультиустройственный
  (`DomovoyHub`+`DomovoyDevice`). Скетчи: `SimpleLed.ino`, `DomovoyMegaGateway.ino`.
  **[НЕ закоммичено]** `Arduino/house/` — боевые прошивки дома владельца (`HouseMega` 17 устройств,
  `HouseDimmer` 2 фазовых диммера), см. [[../memory-bank/... ]] и [decisionLog.md](decisionLog.md).

### Инфраструктура (docker-compose)
- RabbitMQ (bitnami, mqtt+management+prometheus), MongoDB+exporter, Zigbee2MQTT, Prometheus.
- **[Проектируется, НЕ реализовано]** compose-хардening (Эпик 3H/деплой-план): `mongo:7`+cache-limit,
  bitnami→официальный `rabbitmq:4-management`, Prometheus→opt-in профиль `monitoring`.

## Mongo-коллекции (актуальный список, `domovoy` DB)

`capability_devices` (read-модель) · `device_events`/`sensor_readings` (TS feature store) · `zones` ·
`home_state` · `automations`/`auto_history` · `control_blocks`/`block_state`/`block_history` ·
`ml_models`/`ml_tasks` · `proposals` · `users`/`roles` · `dashboards`/`dashboard_prefs` ·
`site_location`/`calendar_settings` · `narrative_entities`/`narrative_state`/`home_story` · `ops_logs`
(capped, Serilog) · **[НЕ закоммичено]** `scenes` (3B) · **[НЕ закоммичено]** `backup_settings` (3A).
Полная схема — [`../docs/architecture/database_schema_ru.md`](../docs/architecture/database_schema_ru.md).

## Потоки данных (актуальные)

- **Discovery/State/Online** — как раньше: Adapter → `Envelope<Device{Discovered,StateReport,OnlineChanged}V1>`
  → `CapabilityDeviceManager` (in-memory) + `EventInterceptor` (Mongo).
- **Команды** — WebUI → `POST /api/device-control/{id}/set` → `DeviceCommandV1` → адаптер → протокол.
  Тот же путь используют: control-block actuation (`source=block:{id}`), правила (`source=automation:{id}`),
  и **[НЕ закоммичено]** активация сцены (`source=scene:{id}`, fan-out батчем).
- **Block-триггеры** — `BlockTriggeredV1` → `block_history` → атрибуция актора в журнале
  (`{kind}:{id}` в `Envelope.Source`, кликабельный `TriggerChip`).
- **Дневник дома** — `DiaryMiner` (события+сцены) → `SceneBuilder` → `SignificanceScorer` →
  `DayConsolidator` → рендер (`RuLanguagePackRenderer`) → `home_story`.
- **[НЕ закоммичено] System-restart** — WebUI → `SystemController` → `SystemControlV1` broadcast по шине
  (`system.control`) → каждый сервис слушает свою очередь `system-control-{name}` → `StopApplication()` →
  docker `restart: unless-stopped` поднимает заново. Опционально (за флагом) — прямой docker.sock control
  через `Docker.DotNet` (рестарт/старт/стоп ЛЮБОГО контейнера, включая инфраструктурные).
- **[НЕ закоммичено] Бэкап/restore** — `BackupService` дампит все пользовательские коллекции Mongo-драйвером
  (без `mongodump`-бинарника) в zip (`manifest.json`+`collections/*.bson`) + настройки плагинов; restore =
  drop+recreate по манифесту → рестарт стека через `SystemControlV1`.

## Status / Известные вопросы (кратко; полная DoD-таблица — roadmap.md)

| Тема | Статус |
|---|---|
| Фазы 0–1.5 (фундамент, автоматизация, живая верификация) | ✅ закрыты |
| Фаза 2 (интеллект: 2A–2Q, все эпики) | ✅ v1-done, часть без вживую-прогона (см. [progress.md](progress.md)) |
| Фаза 3 — 3A Бэкапы/restore | 🚧 v1 реализован **[НЕ закоммичено]**; остаток — живой прогон restore в docker |
| Фаза 3 — 3B Сцены first-class | 🚧 v1 реализован **[НЕ закоммичено]**; остаток — живой прогон, fade отложен |
| Фаза 3 — 3C–3G (энерго/presence/движок правил/уведомления/UX) | ⬜ запланировано, roadmap.md |
| Фаза 3 — 3H Абстракция хранилища (выбор БД) | ⬜ спроектировано (ADR-уровень), код не начат |
| Редизайн `/automations` (Flow удалён) | 🚧 реализовано **[НЕ закоммичено]** |
| System-restart из UI | 🚧 реализовано, self-restart live-verified, **[НЕ закоммичено]** |
| Прошивки `Arduino/house/` | 🚧 адаптированы с ArduinoHA, **[НЕ закоммичено]**, вживую не прошивалось |
| `DeviceOnlineChangedV1` consumer в `CapabilityDeviceManager` | ⬜ не подключён (SignalR online/offline не обновляется этим путём) |

## Tech Stack
.NET 9 · ASP.NET Core · C# 12 · RabbitMQ.Client 7 · MQTTnet 4.3 · MongoDB.Driver 2.23 · Microsoft.ML 3.0.1 ·
Serilog (+ Mongo-sink 5.4) · prometheus-net · SignalR · React 18 + Vite + TS · MUI 5 · recharts ·
`@microsoft/signalr` 8. Ocelot убран (Шаг 5). React Flow — убран вместе с `/flow` **[НЕ закоммичено]**.

## Что дальше
1. **Закоммитить и смёржить текущий рабочий diff** (3A/3B/automations-редизайн/system-restart/house-firmware) —
   ничего из этого сейчас не защищено git-историей. См. [activeContext.md](activeContext.md).
2. Живой прогон 3A (restore в чистом docker-стеке) + 3B (сцена из UI/правила/дашборда → устройство).
3. Боевое развёртывание дома владельца ([`../docs/deployment_plan_ru.md`](../docs/deployment_plan_ru.md)) —
   предусловие «бэкапы» закрыто (v1), остаток — живой прогон + compose-хардening.
4. Дальше по Фазе 3: 3C энергодомен → 3D presence → 3E движок правил → 3F уведомления → 3G UX → 3H БД.
