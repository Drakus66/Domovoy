# Active Context — текущий фокус

> Что только что сделано и что следующее. **Обновлять каждую сессию** при значимых изменениях.
> Полный статус — [progress.md](progress.md); снимок кода — [currentState.md](currentState.md).
> **Последнее обновление:** 2026-07-19.

## ⚠️ Статус коммитов (важно, перепроверено 2026-07-19)

Ветка `epic-3b-scenes` физически идентична `develop` — **0 собственных коммитов**. Последний коммит в
репозитории вообще — `85e2917` (merge `epic-dashboard-fill` → `develop`, включает `19c8b44` «Fix
Automations», 2026-07-17). **Всё, что описано ниже как «done 2026-07-18/2026-07-19», НЕ закоммичено** —
это одна большая пачка изменений в рабочем дереве (79 изменённых + ~45 новых файлов): Эпик 3A (бэкапы),
Эпик 3B (сцены), редизайн UI автоматизаций (`Flow.tsx` фактически всё ещё в HEAD!), хвосты Эпика 2Q
(PID-автотюн), system-restart (`SystemControl`/`SystemController`), прошивки `Arduino/house/`, план-доки
(`deployment_plan_ru.md`/`recommended_devices_ru.md`/`backup_restore_ru.md`/`scenes_ru.md`) и правки
самого `roadmap.md`. Перед любым `git checkout`/`reset`/`clean` — обязательно `git status` и сохранение
этой работы (коммит или `stash -u`).

## Где мы сейчас

**Фазы 0/1/1.5/2 закрыты** (1.5 — живой 3-оконный прогон 2026-07-06). **Forward-фазы перегруппированы по
рыночному исследованию 2026-07-19** (roadmap, решение №6): Фаза 3 = продуктовая зрелость (3A–3I),
Фаза 4 = домен-расширения, Фаза 5 = автономность (бывшая Фаза 3). Ближайший фронт — **боевое развёртывание
малого дома владельца (Эпик 3H, переезд с HA на мини-ПК)** + Фаза 3 (бэкапы 3A — пробел №1).

Ветка интеграции — `develop` (GitFlow; эпики делаются в `epic-*` ветках от `develop`, мержатся в `develop`).

## Недавно сделано

- 🔌 **Эпик 3H: прошивки дома Mega+Nano адаптированы с ArduinoHA на Domovoy Native (2026-07-19,
  `Arduino/house/`, вживую не прошивалось):** `HouseMega` — 17 логических устройств за одной платой-мостом
  (3 света, 3 виртуальных выключателя — легаси двойного клика A5 снято, прожектор одиночным кликом,
  2 климата DHT22+MH-Z19, 5 конвекторов `valve`-ШИМ, 2 вентилятора с разгоном, реле давления воды,
  тумблер калибровки CO2); `HouseDimmer` (Nano) — 2 фазовых диммера с
  CRT-гаммой (`brightness` 0..100 %) + реле. Вся логика на борту — дом работает без сервера; добавлен
  reconnect с переобъявлением и снимком состояний. Попутно `DomovoyClient` стал **header-only (2.2.0)** —
  фикс ODR: `#define`-лимиты до include раньше молча не доезжали до .cpp; в диммере убран
  `Ethernet.maintain()` (no-op при статике, тянул DHCP-код — не влезал в Nano). Проверено сборкой
  PlatformIO: Mega 18 % flash / 48 % RAM, Nano **92 % flash** / 51 % RAM.
  → [`../Arduino/house/README.md`](../Arduino/house/README.md).

- 📋 **Анализ железа + план боевого развёртывания + план абстракции БД (2026-07-19, только анализ/доки, код
  не менялся):** в roadmap добавлены **Эпик 3H** (боевой запуск: мини-ПК x86 с AVX — Pi 4 исключён из-за
  MongoDB≥5.0/ARMv8.2; compose-хардening: `mongo:7`+cache-limit, bitnami→официальный `rabbitmq:4-management`,
  **prometheus → opt-in профиль `monitoring`**, `devices:` для Zigbee-стика; прошивка Mega+Nano на Domovoy
  Native — Nano поддержана by design) и **Эпик 3I** (абстракция хранилища: доменные store-интерфейсы в
  DbGateway → PostgreSQL-коннектор как первая альтернатива, НЕ TimescaleDB; сцепка = 26 файлов/~253 точки
  только в DbGateway + Serilog-sink) + решения №7/№8 в «Принятых решениях». Детали —
  [`../docs/architecture/roadmap.md`](../docs/architecture/roadmap.md) (3H/3I), [decisionLog.md](decisionLog.md).

## Сделано ранее (Фаза 2)

- ✅ **Epic 2N «Дневник дома» — ядро Фазы 0–3 (ветка `develop`, 2026-07-09):** художественная летопись
  жизни дома, детерминированный template-NLG, русский, офлайн, без LLM. Новая библиотека
  `src/Common/Domovoy.Narrative` (язык-нейтральный IR `Beat`/`Scene`/`DayStory` в
  `Domovoy.Contracts.Narrative`; шов `INarrativeRenderer`+селектор; `RuLanguagePackRenderer` на **данных** —
  встроенный `Packs/ru.json`, новый язык = новый пакет). Конвейер в DbGateway: `DiaryMiner`→`SceneBuilder`
  (коалесцинг+причина из System-сенсора 2L)→`SignificanceScorer`→`DayConsolidator` («молчание — фича»)→
  рендер→`HouseDiaryBuilder` материализует `home_story` (ротация `narrative_state`, tier-затухание). API
  `GET /api/home-story`+`POST /preview|/rebuild`, `narrative_entities` (имена духа/жильцов), прокси
  `HomeStoryController`; WebUI — тумблер «Дневник» на `/logs`+диалог имён, ns `diary`. Решение А-vs-B:
  движок in-process (B) как база, плагин/LLM (A) — слой поверх шва (Фаза 4 future). 22 офлайн .NET + 3
  vitest; собирается. **Не прогонялось вживую** (Фаза 1.5).
  → [`../src/Common/Domovoy.Narrative/`](../src/Common/Domovoy.Narrative/).
- ✅ **Кастомные дашборды (ветка `epic-2k-location-settings`, 2026-07-06):** главная страница стала
  вкладочной: **«Все»** (прежний вид по зонам, вынесен в `AllDevicesTab`) + **авто-сферы** (вкладки
  Свет/Климат/Датчики/… собираются сами из архетипов 2D через маппинг категорий `deviceVisuals`,
  скрываемые — самобытная альтернатива конструктору Lovelace, курс «меньше UI») + **свои вкладки**
  (редактор v1 «пикер + секции», без drag-сетки; 4 типа элементов: устройство / одна capability /
  график телеметрии 1B / переключатель режимов 1G; удалённое устройство → плейсхолдер-карточка).
  Бэкенд: коллекции `dashboards` + `dashboard_prefs` (скрытые сферы), `DashboardEndpoints` в DbGateway
  (CRUD + `/order` + `/prefs`, чистый `Normalize`), прокси `DashboardsController` в ApiGateway;
  `Params` элементов — словарь с JsonElement через существующий `JsonObjectDictionarySerializer`
  (закреплено BSON round-trip тестом). WebUI: маршрут `t/:tabId` (all | sphere:<категория> | GUID),
  zustand `dashboardStore`, i18n-неймспейс `dashboards` (ru+en). Тесты: +9 .NET (170/170),
  +12 vitest (62/62); CRUD прогнан вживую через docker (UTF-8, 400 на неизвестный тип, DELETE).
  Дальше: drag-and-drop раскладка, персональные вкладки (после auth Фазы 3).
- ✅ **Epic 2H — LLM-коннекторы-заглушки (ветка `epic-2b`, 2026-07-05):** провайдер-агностичная точка
  расширения `AutomationService/Services/Assistant/`: `IAssistantConnector` (AuthorRule → Proposed-правило
  через 2C; Explain → «почему» поверх 1F) + no-op `DisabledAssistantConnector` (мягкая деградация) +
  фича-флаг `AssistantOptions` (off). Эндпоинты `/api/assistant/status|author-rule|explain` + прокси
  `AssistantController`; WebUI — **без чат-аватара**, только карточка статуса на `/status`. Реальный бэкенд =
  будущая реализация того же интерфейса/плагин 1C. 6 офлайн-юнит. **Замыкает эпики Фазы 2.**
- ✅ **Epic 2F — Движок поиска закономерностей v1 (ветка `epic-2b`, 2026-07-05):** полная воронка поверх
  заглушки 2C. `AutomationService/Services/Discovery/`: `InformationTheory` (MI/условная MI), `ChiSquared`
  (G-тест → p-value через неполную гамму), `Statistics` (BH-FDR); `PatternMiner.Mine` (Stage 0 слоты+as-of →
  Stage 1 условная MI+FDR-скрининг → Stage 2 условие: булев «active»/числовой порог по терцилям + страж по
  времени → Stage 3 support/confidence/lift, учитель только user, anti-loop); `DiscoveryEngine` (BackgroundService
  + `POST /api/discovery/scan`) кладёт `Proposed`-правило + `Proposal` (Source=discovery). WebUI `/proposals`
  кнопка «Искать закономерности». **v1 = тип A** (дискретные политики → правила); тип B/C + Granger/FP-growth —
  дальше. 16 офлайн-юнит. → [`../src/Services/Domovoy.AutomationService/Services/Discovery/`](../src/Services/Domovoy.AutomationService/Services/Discovery/).
- ✅ **Epic 2E — Модель ролей (ветка `epic-2b`, 2026-07-05):** контракт `Domovoy.Contracts/Security/`
  (`WellKnownPermissions` — открытый словарь прав, `Role` с `IsBuiltIn`, `User` без пароля/логина);
  DbGateway `RolesEndpoints` (`/api/roles` CRUD + `/permissions`; built-in защищена от удаления, снимается
  с пользователей при удалении) + `UsersEndpoints` (`/api/users` CRUD) + `SecuritySeeder` (идемпотентный
  засев admin/resident/guest); ApiGateway прокси `RolesController`/`UsersController`; WebUI `/users` (вкладки
  «Пользователи»/«Роли», чекбоксы прав, nav + i18n ru/en). **Без enforcement** (гейтинг = Фаза 3). 4 офлайн-
  юнит + 2 инфра-теста (Docker-gated). → [`../src/Common/Domovoy.Contracts/Security/`](../src/Common/Domovoy.Contracts/Security/).
- ✅ **Epic 2A — ML-субстрат на ML.NET** (merge `epic-2a-ml-substrate`): реестр `ml_models` в DbGateway,
  `MlTrainer`/`MlModelService`/`MlTrainingService` в AutomationService, блок `ml_setpoint`, WebUI `/models`.
  v1 — одна последняя модель. → [`../src/Services/Domovoy.AutomationService/Ml/`](../src/Services/Domovoy.AutomationService/Ml/).
- ✅ **Epic 2G — Центр активности** (merge `epic-2g-activity-center`): Serilog Mongo-sink `ops_logs`,
  `GET /api/activity` (мердж device_events + auto_history + ops_logs), WebUI `/logs`→Activity.
- ✅ **Epic 2D — Семантическая типизация устройств**: `DeviceClassifier` (эвристики) → `AutoArchetype` +
  override; WebUI чип типа/иконки. 12 unit + интеграционный тест (поймал баг writable-over-bus).
- ✅ **Epic 2B — ML-термостат-губернатор** (ветка `epic-2b`, ещё не смержена): `ml_thermostat`, стадии
  Shadow→Bounded→Full, дрифт-монитор с авто-демоцией, backtest-scorecard в `/models`.
- ✅ **Epic 2I, фазы 0–5** (на `epic-2b`): реестр ML-шаблонов (regression/binary/multiclass), зональный
  скоупинг моделей (zone→zone_kind→global) с гейтом промоции, селектор-губернатор, политика
  feature-locality (спроектирована, в обучение ещё не интегрирована — Фаза 4+).
- ✅ **Инфраструктурный спринт (2026-07-03, на `epic-2b`, не закоммичен):** `RabbitMqConnection` —
  ленивое подключение с retry/backoff + авто-восстановление + `BasicQos`(50) + DLQ `domovoy.dlx`
  (вместо вечного requeue); составные индексы Mongo в `TimeSeriesInitializer` (device_events,
  sensor_readings, auto_history); пагинация обучающей выборки ML (снят молчаливый потолок 5000).
  Свежий аудит проекта → [`../PROJECT_ANALYSIS_REPORT.md`](../PROJECT_ANALYSIS_REPORT.md).

## Что следующее

1. **Фаза 1.5 — закрыть верификацию рантайма (главный фронт):** offline-smoke в CI + полный живой 3-оконный
   прогон по [`../docs/runbook.md`](../docs/runbook.md) (адаптеры/Zigbee, правила 1A/1F, блоки 1H/1D, плагины 1C,
   SignalR). Без этого ни один эпик Фазы 2 не подтверждён вживую.
2. **Смержить `epic-2b` в `develop`** — ветка накопила 2B/2I/2C/2G/2D/2J/liveness/i18n/2E/2F/2H.
3. **Хвосты 2F:** тип B (уставки → ML-блок 2B), тип C (feedforward для контуров 1H), полный Granger/FP-growth +
   out-of-time-бэктест внутри движка — умозрительны без реальной истории.
4. Дальше — **Фаза 3** (голос/видео/умные замки + полная авторизация поверх ролей 2E).

## Главные риски / открытые вопросы

- ⚠️ Рантайм против реального RabbitMQ/Mongo/Zigbee **не прогонялся** вне интеграционного data-path теста.
- ⚠️ `DeviceOnlineChangedV1` consumer в `CapabilityDeviceManager` не подключён (события пишутся в Mongo, но SignalR не получает online/offline).
- Per-инстанс выбор ML-модели отложен в 2C (`ControlBlock.Params` только числовые).

## Хвосты внутри закрытых эпиков

1C: in-process ALC, контейнер-на-плагин, Python-пакет · 1D: охлаждение, многозонный полив (E2) ·
1E: визуальный граф блоков, очередь апрува · 1F: Bounded-Active · 1H: E2-композиты/DSL · 2G: каналы доставки.
</content>
