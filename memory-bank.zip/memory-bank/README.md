# Memory Bank — точка входа в проект Domovoy

> **Это первое, что нужно прочитать в начале любой сессии.** Memory-bank — единая навигационная
> точка по проекту: что это, как устроено, где что лежит, какие приняты решения и куда движемся.
> Здесь нет дублирования кода — только актуальное описание и **ссылки на конкретные файлы**.

**Последнее обновление:** 2026-07-19 · **Версия:** 5.0 (актуализация под закрытую Фазу 2 + начатую Фазу 3;
до этого memory-bank отставал на месяц — см. протокол в разделе 6).

> ⚠️ **Коммит-статус (важно перед началом работы):** последний коммит в репозитории — `85e2917`
> (2026-07-17). Большой объём реализованного кода (Эпики 3A/3B, редизайн `/automations`, system-restart,
> `Arduino/house/`) существует **только в рабочем дереве**, не закоммичен. Подробности и список —
> [activeContext.md](activeContext.md) (раздел «Статус коммитов») и [currentState.md](currentState.md).
> Перед `git checkout`/`reset`/`clean` — обязательно `git status` + сохранить эту работу.

---

## 1. Что такое Domovoy (в двух абзацах)

Domovoy — **локальный (offline-first) умный дом на .NET 9**, событийная архитектура поверх
**RabbitMQ** (шина + MQTT-брокер) и **MongoDB** (состояние + time-series feature store). Ядро —
**версионируемый capability-контракт** (`Domovoy.Contracts`): адаптеры протоколов (Zigbee2MQTT,
Domovoy Native) публикуют устройства/состояния как capability, а не как закрытые типы. Поверх —
детерминированные автоматизации, контурное управление (control blocks), объяснимость/реплей и
обучающаяся автоматизация на **ML.NET**.

Продуктовая ставка — **обучающаяся автоматизация** (ML предлагает уставки/правила, детерминированный
контур исполняет, безопасный пол вето сверху), **объяснимость/реплей** и **offline-first как
проверяемый инвариант**. Это, а не богатые дашборды, отличает Domovoy от Home Assistant/Homey.
Подробное позиционирование и «рвы» — [`../docs/architecture/positioning_ru.md`](../docs/architecture/positioning_ru.md).

---

## 2. Источники правды (single source of truth)

Чтобы memory-bank не протухал снова, **детали живут в двух авторитетных документах**, остальные
файлы их не дублируют, а ссылаются:

| Документ | Чему авторитет | Когда читать |
|---|---|---|
| **[currentState.md](currentState.md)** | Полный снимок **текущего состояния кода**: сервисы, эндпоинты, потоки данных, статус-таблица | Нужно точно понять, что и как сейчас реализовано |
| **[`../docs/architecture/roadmap.md`](../docs/architecture/roadmap.md)** | **Дорожная карта**: фазы, эпики, DoD, что сделано/в работе/запланировано, принятые с владельцем решения | Нужно понять, куда движемся и почему |

При расхождении любого файла memory-bank с этими двумя — **верь этим двум** и поправь устаревший файл.

---

## 3. Оглавление memory-bank

| Файл | Назначение | Глубина |
|---|---|---|
| **[README.md](README.md)** (этот файл) | Точка входа, навигация, «где что лежит», протокол обновления | стабильный |
| **[currentState.md](currentState.md)** | Авторитетный снимок текущей архитектуры и реализации | живой |
| **[systemOverview.md](systemOverview.md)** | Визуальная схема: сервисы, шина, потоки данных, tech stack | живой |
| **[productContext.md](productContext.md)** | Компоненты, проекты решения, технологический стек | живой |
| **[systemPatterns.md](systemPatterns.md)** | Архитектурные паттерны и инварианты (capability, конверт, feature store, слоистое управление…) | стабильный |
| **[decisionLog.md](decisionLog.md)** | Ключевые принятые решения и их обоснование (со ссылками) | по мере решений |
| **[progress.md](progress.md)** | Статус по фазам/эпикам (зеркало roadmap) | живой |
| **[progressDashboard.md](progressDashboard.md)** | Краткий статус-дашборд (сводка) | живой |
| **[activeContext.md](activeContext.md)** | Текущий фокус: что только что сделано, что следующее | каждую сессию |
| **[quickReference.md](quickReference.md)** | Быстрый старт: команды, ключевые файлы, где что искать | по мере изменений |

---

## 4. Где что лежит (карта репозитория)

> Полное описание каждого компонента — в [currentState.md](currentState.md) и [productContext.md](productContext.md).

**Backend-сервисы** (`src/Services/`):
- [`Domovoy.UnifiedDeviceService`](../src/Services/Domovoy.UnifiedDeviceService/) — capability-реестр, переизлучение состояния в SignalR
- [`Domovoy.Connectivity`](../src/Services/Domovoy.Connectivity/) — адаптеры протоколов (Zigbee2MQTT, Domovoy Native), один MQTT-клиент
- [`Domovoy.AutomationService`](../src/Services/Domovoy.AutomationService/) — движок правил (1A), control blocks (1H/1D), реплей/Shadow (1F), режимы (1G), **ML** (2A, `Ml/`)
- [`Domovoy.PluginSupervisor`](../src/Services/Domovoy.PluginSupervisor/) — реестр + супервизор внепроцессных плагинов (1C)

**Шлюзы** (`src/Gateway/`):
- [`Domovoy.DbGateway`](../src/Gateway/Domovoy.DbGateway/) — Minimal-API + MongoDB; `Endpoints/`, `Models/`, `Services/EventInterceptor.cs` (feature store)
- [`Domovoy.ApiGateway`](../src/Gateway/Domovoy.ApiGateway/) — тонкие прокси-контроллеры + SignalR-хаб `/hub/devices`

**Контракты и общие библиотеки** (`src/Common/`):
- [`Domovoy.Contracts`](../src/Common/Domovoy.Contracts/) — **сердце системы**: `Envelope`, capability-модель, `BusTopology`, payload-контракты, archetype, ML, blocks, Security (2E), Narrative (2N), Scenes (3B, НЕ закоммичено)
- [`Domovoy.Common`](../src/Common/Domovoy.Common/) — `BaseCommand/BaseEvent`, SignalR-релей-событие, Serilog bootstrap (`Logging/SerilogBootstrap.cs`)
- [`Domovoy.MessageBus`](../src/Common/Domovoy.MessageBus/) — `IMessageBus` + `RabbitMqConnection` + `SystemControl.cs` (self-restart по шине, НЕ закоммичено)
- [`Domovoy.Narrative`](../src/Common/Domovoy.Narrative/) — язык-нейтральный NLG-движок «Дневника дома» (2N): IR (`Beat`/`Scene`/`DayStory`) + `RuLanguagePackRenderer`

**Прочее:**
- [`src/UI/WebUI/`](../src/UI/WebUI/) — React + Vite + MUI; страницы в `src/pages/` (Devices, DeviceRegistry, Zones, Modes, Automations, Blocks, Plugins, Models, Proposals, Users, Zigbee, Settings, Logs→Activity, SystemStatus, Scenes — НЕ закоммичено). Список — [quickReference.md](quickReference.md)
- [`src/Plugins/Domovoy.CommutePlugin/`](../src/Plugins/Domovoy.CommutePlugin/) — первый живой внепроцессный плагин (Epic 2M.1)
- [`src/Tools/Domovoy.DeviceEmulator/`](../src/Tools/Domovoy.DeviceEmulator/) — реф-реализация Domovoy Native v1 + веб-UI (`:5080`), локальный инструмент (не в docker)
- [`tests/Domovoy.IntegrationTests/`](../tests/Domovoy.IntegrationTests/) — xUnit + Testcontainers (реальные RabbitMQ + Mongo)
- [`Arduino/`](../Arduino/) — прошивка `DomovoyClient` v2 (мультиустройственная, header-only) + [`Arduino/house/`](../Arduino/house/) (боевые прошивки дома владельца, НЕ закоммичено, не прошивалось)
- [`docker-compose.yml`](../docker-compose.yml) — оркестрация стека (RabbitMQ, MongoDB, Zigbee2MQTT, Prometheus)

---

## 5. Внешняя документация (за пределами memory-bank)

| Документ | О чём |
|---|---|
| [`../docs/runbook.md`](../docs/runbook.md) | Как поднять стек, эмулятор, сквозной 3-оконный сценарий |
| [`../docs/architecture/roadmap.md`](../docs/architecture/roadmap.md) | Дорожная карта (фазы 0–3, эпики, DoD) |
| [`../docs/architecture/positioning_ru.md`](../docs/architecture/positioning_ru.md) | Позиционирование, конкурентный анализ, три «рва» |
| [`../docs/architecture/database_schema_ru.md`](../docs/architecture/database_schema_ru.md) | Схема коллекций MongoDB |
| [`../docs/architecture/coding_standards_ru.md`](../docs/architecture/coding_standards_ru.md) | Стандарты кода |
| [`../docs/architecture/architecture_diagrams_ru.md`](../docs/architecture/architecture_diagrams_ru.md) | Диаграммы архитектуры |
| [`../docs/architecture/layered_architecture_ru.md`](../docs/architecture/layered_architecture_ru.md) | ⚠️ устарело (историческая 6-сервисная архитектура) |
| [`../docs/backup_restore_ru.md`](../docs/backup_restore_ru.md) | Бэкапы/восстановление (Эпик 3A, НЕ закоммичено) |
| [`../docs/scenes_ru.md`](../docs/scenes_ru.md) | Сцены как first-class объект (Эпик 3B, НЕ закоммичено) |
| [`../docs/deployment_plan_ru.md`](../docs/deployment_plan_ru.md) | Боевое развёртывание дома владельца (решение №7, не эпик карты) |
| [`../docs/recommended_devices_ru.md`](../docs/recommended_devices_ru.md) | Рекомендованная периферия (ESP32-POE-ISO, CO₂-сенсоры и т.д.) |
| [`marketResearch2026.md`](marketResearch2026.md) | Deep-research рынка 2026 — обоснование перегруппировки Фазы 3 |
| [`../README.md`](../README.md) | Корневой README репозитория |

---

## 6. Протокол ведения memory-bank (важно)

**В начале сессии:** прочитать этот README → [activeContext.md](activeContext.md) (текущий фокус) →
при необходимости [currentState.md](currentState.md).

**При значимых изменениях кода/решениях — обновлять обязательно:**
1. **[currentState.md](currentState.md)** — статус-таблица и описание затронутого компонента (главный апдейт).
2. **[`../docs/architecture/roadmap.md`](../docs/architecture/roadmap.md)** — статус эпика/DoD, если закрыт этап.
3. **[activeContext.md](activeContext.md)** — «что только что сделано / что следующее».
4. **[decisionLog.md](decisionLog.md)** — если принято архитектурное решение (с обоснованием и ссылкой).
5. Остальные файлы (`systemOverview`/`productContext`/`progress`/`progressDashboard`/`quickReference`) —
   только если изменилось то, что они описывают (структура, стек, статус фаз, команды).

**Принципы, чтобы не протухало снова:**
- Не дублировать волатильные детали — ссылаться на источники правды (раздел 2).
- Любой статус/факт сопровождать ссылкой на конкретный файл кода.
- Если информации нет в memory-bank — давать **ссылку на расположение**, а не пересказ.
- Менять дату «Последнее обновление» в шапке затронутого файла.

> Папка `memory-bank/` — **в `.gitignore`** (локальный контекст, не коммитится). Внешние доки
> (`runbook.md`, `roadmap.md`) ссылаются на [currentState.md](currentState.md) как на снимок состояния.
</content>
</invoke>
