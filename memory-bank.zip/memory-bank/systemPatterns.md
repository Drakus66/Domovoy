# System Patterns — паттерны и инварианты Domovoy

> Архитектурные паттерны и сквозные принципы, действующие в коде. Меняются редко.
> Реализацию см. в [currentState.md](currentState.md); обоснования — в [decisionLog.md](decisionLog.md).
> **Последнее обновление:** 2026-07-19 (паттерны стабильны с 06-14, добавлены сцены/бэкапы ниже).

## Опорные принципы (на всех фазах)

1. **Слоистое управление.** Детерминированный безопасный пол (правила/расписания) → пользовательские уставки → ML-оптимизация сверху. Критичные домены (отопление, доступ) **никогда** не зависят только от ML/облака/UI.
2. **Offline-first как проверяемый инвариант.** Облако физически не может оказаться в критическом пути; проверяется offline-smoke-тестом. Облачные интеграции — опциональные плагины.
3. **Resource-aware модульность.** Плагины декларируют CPU/RAM/GPU/internet; супервизор включает тяжёлое только при наличии ресурсов.
4. **Contract-first.** Всё привязано к версионируемой схеме событий/команд (`Domovoy.Contracts`), а не к внутренним классам.
5. **Fail-safe и модульность.** Падение одного сервиса/плагина не валит остальные; критичное состояние восстанавливается из БД.
6. **Сначала данные, потом ML.** Сбор телеметрии/event-log запущен задолго до моделей.

Канонический список с пояснениями — [`../docs/architecture/roadmap.md`](../docs/architecture/roadmap.md), раздел «Опорные принципы».

## Архитектурные паттерны

### Capability-контракт (вместо закрытых типов устройств)
Устройство = `DeviceDescriptor` + набор **открытых** `Capability(id, kind, attrs)` (`on_off`, `brightness`,
`temperature`, `co2`, `presence`, `lock`, `valve`…). Закрытый enum `Light/Sensor/Switch` и `IDeviceTypeHandler`
удалены. Codec живёт **per-adapter** (Z2M `exposes`→capability), расширение без перекомпиляции ядра.
→ [`Capability.cs`](../src/Common/Domovoy.Contracts/Capabilities/Capability.cs), [`WellKnownCapabilities.cs`](../src/Common/Domovoy.Contracts/Capabilities/WellKnownCapabilities.cs).

### Конверт сообщений (CloudEvents) + единое именование шины
Все сообщения — `Envelope<T>` (CloudEvents 1.0: id/type/source/subject/time/correlationid/data).
Имена exchange/routing-key кодифицированы в `BusTopology` (dotted `domovoy.<domain>`), «магических строк» нет.
→ [`Envelope.cs`](../src/Common/Domovoy.Contracts/Messaging/Envelope.cs), [`BusTopology.cs`](../src/Common/Domovoy.Contracts/Messaging/BusTopology.cs).

### Детерминированные идентификаторы
`DeviceIdFactory.Derive(adapterSource, hardwareId)` → стабильный RFC-4122 v5 id; команды роутятся к
владеющему адаптеру по id даже на холодном кэше.

### Event-log как реплейабельный feature store (а не просто лог)
`EventInterceptor` пишет append-only `device_events` (Mongo time-series) с **дельтой `old→new`**,
`triggerSource` (user/rule/device/ml), `ruleId`/`decisionId`, `mode`/`context`, `correlationId`.
Это топливо ML и основа реплея/объяснимости. **Serilog — отдельно**, только для ops-диагностики
(опц. Mongo-sink `ops_logs`). Не смешивать домен и операционку.
→ [`EventInterceptor.cs`](../src/Gateway/Domovoy.DbGateway/Services/EventInterceptor.cs), [`DeviceEventLog.cs`](../src/Gateway/Domovoy.DbGateway/Models/DeviceEventLog.cs).

### Control block = виртуальное capability-устройство
Stateful-блок (`Tick`) проецируется как виртуальное устройство: анонс `DeviceDiscoveredV1` + выходы
`DeviceStateReportV1` (`source=block:{id}`) → бесплатно UI/история/зоны/команды. **Композиция** = вход
блока привязан к capability другого устройства; `DeviceRegistry` = blackboard. Уставки — командой на
вирт. устройство. **ML-блок** (`ml_setpoint`) — частный случай: грузит модель, эмитит уставку.
→ [`BlockSdk.cs`](../src/Services/Domovoy.AutomationService/Blocks/BlockSdk.cs), [`BlockRuntime.cs`](../src/Services/Domovoy.AutomationService/Blocks/BlockRuntime.cs).

### Безопасный пол (safety floor)
Защитные правила из локального `safety-rules.json` (protected, не отключаются из UI, работают без БД/UI):
антизамерзание, CO₂→вентиляция, дым→разблокировать замки. Клампит выходы ML на всех стадиях.

### Стадийный выкат полномочий
`Proposed → Shadow (логирует, не актуирует) → Bounded-Active (узкая клампленная полоса) → Full`.
Для ML апрувится **версия модели + стадия**, не отдельные выходы; дрейф → авто-демоут в Shadow.

### Replay = прод-семантика
`ReplayService` прогоняет правило по историческим дельтам тем же `RuleEvaluator`, что и живой движок,
без публикации команд (dry-run). → [`ReplayService.cs`](../src/Services/Domovoy.AutomationService/Services/ReplayService.cs).

### Resource-aware плагины (внепроцессные)
Манифест `plugin.json` (capabilities/subscriptions/commands/permissions + ресурсы) × `HostResources` →
`Blocked` при нехватке; удовлетворимые запускаются **отдельными процессами** (изоляция), рестарт с backoff.

### Прокси-шлюзы
ApiGateway — **тонкие** контроллеры (прокси к DbGateway либо publish на шину), без бизнес-логики.
DbGateway — единственный владелец Mongo (персист зон/режима/правил/блоков/ML/feature store).

### Сцена = именованный снапшот capability-состояний (Эпик 3B, **НЕ закоммичено**)
Сцена не исполняет логику — она хранит целевые значения набора устройств и активируется через **уже
существующий** actuation-путь (батч `DeviceCommandV1`, как в 1D). Редактирование значений сцены **не**
применяет их к дому (обязательное требование, избегает боли WTH-2024 из HA); Re-Capture — снять текущее
состояние writable-capability в сцену одной кнопкой. → [`Scenes/Scene.cs`](../src/Common/Domovoy.Contracts/Scenes/).

### Бэкап = дамп через тот же Mongo-драйвер, не отдельный бинарник (Эпик 3A, **НЕ закоммичено**)
Полный bundle (все пользовательские коллекции + TS-опции + настройки плагинов) собирается `IMongoDatabase`
напрямую (без `mongodump`), поэтому переносим на любой хост без внешних утилит. Restore = drop+recreate по
манифесту → рестарт стека через `SystemControlV1` (не ручной docker restart). Zigbee-координатор — отдельный
трек (радио нельзя дампнуть из Mongo).

## Реализационные конвенции

- **Открытые модели вместо enum:** режимы (`WellKnownModes`), архетипы (`DeviceArchetypes`), capability — строки-расширяемо.
- **Конфиги = документы Mongo** (CRUD по паттерну `automations`), грузятся `RefreshLoop`/`*Store` по HTTP.
- **Strongly-typed options** (`TelemetryOptions`, `AutomationOptions`) через `IOptions`.
- **Time-series инициализация** на старте (`TimeSeriesInitializer`: создание + TTL через `collMod`).
- **Тесты:** unit (xUnit) + интеграционные на Testcontainers (реальные RabbitMQ+Mongo, локальные → offline-инвариант).

Стандарты кода — [`../docs/architecture/coding_standards_ru.md`](../docs/architecture/coding_standards_ru.md).
</content>
