# Quick Reference — быстрый старт

> Шпаргалка: что это, ключевые файлы, команды, где что искать. Полная навигация — [README.md](README.md).
> **Последнее обновление:** 2026-07-19.

## Что такое Domovoy

Локальный (offline-first) умный дом на **.NET 9** · событийная архитектура на **RabbitMQ** + **MongoDB** ·
ядро = **capability-контракт** · обучающаяся автоматизация на **ML.NET** · объяснимость/реплей.
Фазы 0–2 закрыты, идёт Фаза 3 (продуктовая зрелость — бэкапы/сцены/энергодомен/presence/…).

## Архитектура одной строкой

```
WebUI → ApiGateway (прокси + SignalR) → RabbitMQ (шина+MQTT) → {Connectivity, UnifiedDeviceService,
        AutomationService, PluginSupervisor} ; DbGateway → MongoDB
```

4 backend-сервиса + 2 шлюза. Схема — [systemOverview.md](systemOverview.md).

## Ключевые файлы

| Что | Где |
|---|---|
| **Контракт (ядро)** | [`src/Common/Domovoy.Contracts/`](../src/Common/Domovoy.Contracts/) — `Messaging/Envelope.cs`, `Messaging/BusTopology.cs`, `Capabilities/`, `Scenes/` (НЕ закоммичено) |
| Шина | [`src/Common/Domovoy.MessageBus/`](../src/Common/Domovoy.MessageBus/) — `RabbitMqConnection`, `SystemControl.cs` (НЕ закоммичено) |
| Адаптеры протоколов | [`src/Services/Domovoy.Connectivity/Adapters/`](../src/Services/Domovoy.Connectivity/Adapters/) — Zigbee2Mqtt / DomovoyNative / EspHomeMqtt |
| Правила/блоки/реплей/ML/дневник | [`src/Services/Domovoy.AutomationService/`](../src/Services/Domovoy.AutomationService/) (`Blocks/`, `Services/Discovery/`, `Services/ReplayService.cs`, `Ml/`) |
| Дневник дома (NLG) | [`src/Common/Domovoy.Narrative/`](../src/Common/Domovoy.Narrative/) |
| Плагины | [`src/Services/Domovoy.PluginSupervisor/`](../src/Services/Domovoy.PluginSupervisor/), реальный плагин — [`src/Plugins/Domovoy.CommutePlugin/`](../src/Plugins/Domovoy.CommutePlugin/) |
| Персист + feature store | [`src/Gateway/Domovoy.DbGateway/`](../src/Gateway/Domovoy.DbGateway/) (`Endpoints/`, `Services/EventInterceptor.cs`, `Services/BackupService.cs` — НЕ закоммичено) |
| Прокси + SignalR | [`src/Gateway/Domovoy.ApiGateway/Controllers/`](../src/Gateway/Domovoy.ApiGateway/Controllers/) |
| WebUI | [`src/UI/WebUI/src/pages/`](../src/UI/WebUI/src/pages/) — 16 страниц, см. ниже |
| Эмулятор Native | [`src/Tools/Domovoy.DeviceEmulator/`](../src/Tools/Domovoy.DeviceEmulator/) (`:5080`) |
| Прошивки дома | [`Arduino/house/`](../Arduino/house/) (НЕ закоммичено, не прошивалось) |
| Интеграционные тесты | [`tests/Domovoy.IntegrationTests/`](../tests/Domovoy.IntegrationTests/) |

## Команды

```bash
# Поднять инфраструктуру (RabbitMQ, Mongo, Zigbee2MQTT, Prometheus)
docker-compose up -d

# Сборка / тесты
dotnet build Domovoy.sln
dotnet test                       # вкл. Testcontainers-интеграционные (нужен Docker)

# Запуск сервиса локально
dotnet run --project src/Services/Domovoy.AutomationService

# WebUI
cd src/UI/WebUI && npm install && npm run dev    # типизация: npx tsc --noEmit ; тесты: npm test

# Эмулятор устройств (Native v1)
dotnet run --project src/Tools/Domovoy.DeviceEmulator   # UI на :5080
```

Полный сценарий запуска + 3-оконный прогон — [`../docs/runbook.md`](../docs/runbook.md).

## Полезные адреса (dev)

- RabbitMQ management: http://localhost:15672
- Prometheus: http://localhost:9090
- ApiGateway: `/metrics`, SignalR-хаб `/hub/devices`, Swagger
- Эмулятор: http://localhost:5080

## WebUI-страницы (актуальный список `src/pages/`)

`/` (Devices.tsx — главная, вкладки Все/сферы/свои + `t/:tabId`) · `/devices` (DeviceRegistry.tsx — плоский
реестр-таблица) · `/zones` · `/modes` · `/automations` (мульти-триггер/условие/действие) · `/blocks` ·
`/plugins` · `/models` (ML-хаб) · `/proposals` (очередь апрува) · `/users` (роли) · `/zigbee` · `/settings`
(геолокация+календарь; **+ бэкапы, НЕ закоммичено**) · `/logs` (Activity + Дневник дома) · `/status`
(**+ SystemControlCard, НЕ закоммичено**) · **`/scenes`** (НЕ закоммичено, 3B).
`/flow` (React Flow редактор) **физически ещё присутствует в HEAD**, но признан дублем и удалён в рабочем
дереве (НЕ закоммичено) — см. [activeContext.md](activeContext.md).

## Где что искать

- **Текущее состояние кода** → [currentState.md](currentState.md)
- **Куда движемся / почему** → [`../docs/architecture/roadmap.md`](../docs/architecture/roadmap.md)
- **Паттерны/инварианты** → [systemPatterns.md](systemPatterns.md)
- **Принятые решения** → [decisionLog.md](decisionLog.md)
- **Текущий фокус + коммит-статус** → [activeContext.md](activeContext.md)
- **Схема БД** → [`../docs/architecture/database_schema_ru.md`](../docs/architecture/database_schema_ru.md)
- **Позиционирование/конкуренты** → [`../docs/architecture/positioning_ru.md`](../docs/architecture/positioning_ru.md)
- **Рыночное исследование 2026 (обоснование Фазы 3)** → [`marketResearch2026.md`](marketResearch2026.md)
- **Бэкапы/восстановление** → [`../docs/backup_restore_ru.md`](../docs/backup_restore_ru.md)
- **Сцены** → [`../docs/scenes_ru.md`](../docs/scenes_ru.md)
- **Боевое развёртывание** → [`../docs/deployment_plan_ru.md`](../docs/deployment_plan_ru.md)

## Git workflow

GitFlow: `develop` = интеграция; эпики — в ветках `epic-*` от `develop`, мерж обратно в `develop`; `master` = релизы.
**Сейчас:** ветка `epic-3b-scenes` = `develop` tip (без своих коммитов); весь текущий фронт работы (3A/3B/
редизайн automations/system-restart/house-firmware) сидит некоммиченным в рабочем дереве — см. предупреждение
в [activeContext.md](activeContext.md) перед любым `git checkout`/`reset`/`clean`.
