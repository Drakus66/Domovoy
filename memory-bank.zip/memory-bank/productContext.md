# Product Context — компоненты и стек Domovoy

> Состав решения и технологический стек. Авторитетное описание реализации — [currentState.md](currentState.md).
> **Последнее обновление:** 2026-07-19.

## Обзор продукта

Domovoy — **локальный умный дом на .NET 9** с событийной архитектурой (RabbitMQ + MongoDB) и
**capability-контрактом** как ядром. Продуктовая ставка: обучающаяся автоматизация (ML.NET) +
объяснимость/реплей + offline-first как проверяемый инвариант. Позиционирование —
[`../docs/architecture/positioning_ru.md`](../docs/architecture/positioning_ru.md).

**Идеология имени:** домовой — дух дома из славянского фольклора, хранитель, следящий за домом
и порядком в нём. Проект — этот дух в технологическом воплощении: система сама ведёт хозяйство
по заданному человеком укладу (аналогия — Джарвис-дворецкий), а не служит пультом устройств.
Подробнее — раздел «Идеология имени» в positioning_ru.md.

## Проекты решения (`Domovoy.sln`)

### Контракты и общие библиотеки — `src/Common/`
- **[Domovoy.Contracts](../src/Common/Domovoy.Contracts/)** (zero deps) — ядро: `Envelope<T>` (CloudEvents 1.0), открытая capability-модель (`Capability`/`CapabilityState`/`WellKnownCapabilities`), `DeviceDescriptor`/`DeviceIdentity`/`DeviceIdFactory` (RFC-4122 v5), `BusTopology`, `MessageTypes` (`*.v1`), payload-контракты, `Automations/`, `Blocks/`, `Home/`, `Ml/`, `Plugins/`, `Devices/DeviceArchetypes`, `NativeProtocol`.
- **[Domovoy.Common](../src/Common/Domovoy.Common/)** — `BaseCommand`/`BaseEvent`, `DeviceStateUpdatedEvent` (SignalR-релей), `ZigbeeBridge*`, `MessageBusConfiguration` (живые константы), `Logging/SerilogBootstrap`.
- **[Domovoy.MessageBus](../src/Common/Domovoy.MessageBus/)** — `IMessageBus` + `RabbitMqConnection` (ленивая декларация exchange).

### Backend-сервисы — `src/Services/`
- **[Domovoy.UnifiedDeviceService](../src/Services/Domovoy.UnifiedDeviceService/)** — `CapabilityDeviceManager` (capability-реестр + SignalR-переизлучение).
- **[Domovoy.Connectivity](../src/Services/Domovoy.Connectivity/)** — `AdapterManager` + `Adapters/` (Zigbee2MqttAdapter, DomovoyNativeAdapter).
- **[Domovoy.AutomationService](../src/Services/Domovoy.AutomationService/)** — `AutomationEngine`/`AutomationScheduler`/`ActionExecutor` (1A), `Blocks/` (BlockSdk/BlockCatalog/BlockRuntime/GenericBlocks/PidBlock/composites — 1H/1D/2Q), `Services/ReplayService` (1F), режимы (1G), `Ml/` (MlTrainer/MlModelService/MlTrainingService/governors — 2A/2B/2I/2P), `Services/Discovery/` (pattern-mining — 2F), `Services/Assistant/` (2H). **[НЕ закоммичено]** `Blocks/PidAutotune.cs` (2Q-хвост).
- **[Domovoy.PluginSupervisor](../src/Services/Domovoy.PluginSupervisor/)** — `Plugins/PluginSupervisor`, `Resources/HostResources` (1C).
- **[Domovoy.Narrative](../src/Common/Domovoy.Narrative/)** (2N) — NLG-движок «Дневника дома»: IR (Beat/Scene/DayStory) + `RuLanguagePackRenderer` (данные `Packs/ru.json`).

### Шлюзы — `src/Gateway/`
- **[Domovoy.DbGateway](../src/Gateway/Domovoy.DbGateway/)** — `Endpoints/` (Zone/History/Mode/Blocks/Ml/MlTask/Activity/Roles/Users/Proposals/Dashboard/Settings/NarrativeEntity/HomeStory/Scene[НЕ закоммичено]/Backup[НЕ закоммичено]), `Models/`, `Services/EventInterceptor` (feature store), `Services/DeviceClassifier` (2D), `Services/TimeSeriesInitializer`, `Services/DiaryMiner`+`HouseDiaryBuilder` (2N), `Services/BackupService`+`BackupScheduler` (3A, НЕ закоммичено).
- **[Domovoy.ApiGateway](../src/Gateway/Domovoy.ApiGateway/)** — `Controllers/` (тонкие прокси), SignalR-хаб `/hub/devices`, `EventRelayService`. **[НЕ закоммичено]** `ScenesController`, `BackupController`, `SystemController`+`Services/ContainerControl.cs`.

### Инструменты, UI, тесты, железо
- **[Domovoy.DeviceEmulator](../src/Tools/Domovoy.DeviceEmulator/)** — реф Domovoy Native v1 + веб-UI (`:5080`), не в docker.
- **[Domovoy.CommutePlugin](../src/Plugins/Domovoy.CommutePlugin/)** — первый живой внепроцессный плагин (2M.1).
- **[WebUI](../src/UI/WebUI/)** — React + Vite + MUI; 16 страниц (`src/pages/`), см. [quickReference.md](quickReference.md). React Flow (`/flow`) удалён в рабочем дереве, **НЕ закоммичено**.
- **[Domovoy.IntegrationTests](../tests/Domovoy.IntegrationTests/)** — xUnit + Testcontainers (реальные RabbitMQ + Mongo).
- **[Arduino](../Arduino/)** — `DomovoyClient` v2 (header-only 2.2.0, мультиустройственный: `DomovoyHub` + `DomovoyDevice`); **[НЕ закоммичено]** `Arduino/house/` — боевые прошивки дома владельца.

## Технологический стек

- **Backend:** .NET 9 · C# 12 · ASP.NET Core (Minimal API + BackgroundService) · Microsoft.Extensions.DI
- **Шина:** RabbitMQ (AMQP + MQTT plugin) · `RabbitMQ.Client` 7 · `MQTTnet` 4.3
- **БД:** MongoDB (`MongoDB.Driver` 2.23) — состояние + time-series (`device_events`, `sensor_readings`)
- **ML:** `Microsoft.ML` 3.0.1
- **Реалтайм:** SignalR · `@microsoft/signalr` 8
- **Наблюдаемость:** Serilog (опц. Mongo-sink `Serilog.Sinks.MongoDB` 5.4 → `ops_logs`) · prometheus-net · Prometheus
- **Frontend:** React 18 · Vite · TypeScript · MUI 5 · React Flow · recharts
- **Инфра:** Docker Compose (RabbitMQ, MongoDB+exporter, Zigbee2MQTT, Prometheus)
- **Hardware:** Arduino (UNO/ESP8266/ESP32)

## Коллекции MongoDB (БД `domovoy`)

`capability_devices` (read-модель) · `device_events`/`sensor_readings` (TS, feature store) · `zones` ·
`home_state` · `automations`/`auto_history` · `control_blocks`/`block_state`/`block_history` ·
`ml_models`/`ml_tasks` · `proposals` · `users`/`roles` · `dashboards`/`dashboard_prefs` ·
`site_location`/`calendar_settings` · `narrative_entities`/`narrative_state`/`home_story` ·
`ops_logs` (capped, Serilog-sink) · **[НЕ закоммичено]** `scenes` (3B) · `backup_settings` (3A).
Схема — [`../docs/architecture/database_schema_ru.md`](../docs/architecture/database_schema_ru.md).

## Текущий статус разработки

- **Готово:** capability-миграция (Фаза 0), вся Фаза 1 (1A–1H), Фаза 1.5 (живая верификация), вся Фаза 2 (2A–2Q, v1).
- **В работе (Фаза 3, продуктовая зрелость):** 3A бэкапы + 3B сцены — v1 реализованы, **НЕ закоммичены**;
  редизайн `/automations`, system-restart, `Arduino/house/` — реализованы в той же незакоммиченной пачке.
- **Не проверено вживую (docker-стек):** большая часть Фазы 2/3 — собрано и протестировано юнит/
  интеграционно (Testcontainers), но не прогонялось против полного живого стека (кроме data-path,
  3-оконного сценария, Commute-плагина, дашбордов, self-restart на db-gateway).

Детальный статус — [progress.md](progress.md) и [`../docs/architecture/roadmap.md`](../docs/architecture/roadmap.md).
</content>
