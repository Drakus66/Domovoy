# System Overview — архитектура Domovoy

> Визуальная карта системы. Авторитетный детальный снимок — [currentState.md](currentState.md);
> дорожная карта — [`../docs/architecture/roadmap.md`](../docs/architecture/roadmap.md).
> **Последнее обновление:** 2026-07-19.

## Архитектура (актуальная: 4 сервиса + 2 шлюза)

```
                         ┌──────────────────────────┐
                         │  WebUI (React+Vite+MUI)   │
                         │  /devices /automations …  │
                         └────────────┬──────────────┘
                                HTTP  │  SignalR (/hub/devices)
                         ┌────────────▼──────────────┐
                         │   Domovoy.ApiGateway       │  тонкие прокси + SignalR-релей
                         │   (endpoint routing, JWT   │  + Swagger + Prometheus /metrics
                         │    за флагом, off по умолч.)│
                         └───────┬───────────┬────────┘
                          HTTP   │           │  publish/subscribe
                  ┌──────────────▼──┐   ┌────▼──────────────────────────────────┐
                  │ Domovoy.DbGateway│  │        RabbitMQ (AMQP + MQTT plugin)   │
                  │ Minimal-API+Mongo│  │   exchanges: domovoy.discovery/.state/ │
                  │ EventInterceptor │◄─┤   .commands/.events  (BusTopology)     │
                  │ (feature store)  │  └──┬───────────┬───────────┬─────────────┘
                  └────────┬─────────┘     │           │           │
                           │         ┌─────▼─────┐ ┌───▼────────┐ ┌▼──────────────┐
                     ┌─────▼─────┐   │Connectivity│ │ Unified-   │ │ Automation-   │
                     │  MongoDB  │   │ адаптеры:  │ │ DeviceSvc  │ │ Service       │
                     │ capability_│  │ Z2M+Native │ │ capability │ │ rules(1A)+    │
                     │ devices,   │  │ 1 MQTT-    │ │ реестр →   │ │ blocks(1H/1D)+│
                     │ device_    │  │ клиент     │ │ SignalR    │ │ replay(1F)+   │
                     │ events(TS),│  └─────┬──────┘ └────────────┘ │ modes(1G)+    │
                     │ sensor_    │        │ MQTT                  │ ML(2A)        │
                     │ readings(TS)│  ┌─────▼──────────────┐       └───────────────┘
                     │ ml_models, │   │ Zigbee2MQTT /      │       ┌───────────────┐
                     │ ops_logs…  │   │ Domovoy Native     │       │ PluginSupervis.│
                     └────────────┘   │ устройства         │       │ внепроц.плагины│
                                      └────────────────────┘       │ (1C, отд.проц.)│
                                                                   └───────────────┘
```

**Backend-сервисы (4):**
- **[UnifiedDeviceService](../src/Services/Domovoy.UnifiedDeviceService/)** — `CapabilityDeviceManager`: подписан на discovery/state по шине, держит in-memory capability-реестр, переизлучает нормализованное состояние в SignalR.
- **[Connectivity](../src/Services/Domovoy.Connectivity/)** — `AdapterManager` (один MQTT-клиент) маршрутизирует по `IProtocolAdapter.CanHandleTopic`; адаптеры **Zigbee2MqttAdapter** (codec exposes↔capability), **DomovoyNativeAdapter** (capability-native, liveness watchdog) и **EspHomeMqttAdapter** (2J, HA MQTT Discovery↔capability).
- **[AutomationService](../src/Services/Domovoy.AutomationService/)** — движок правил `trigger→condition→action` (1A) + планировщик cron/sun + безопасный пол; **control blocks** — 25+ обобщённых примитивов + PID + expression + композиты (1H/1D/2Q); **реплей/Shadow** (1F); **режимы дома** (1G, presence через блок `presence_mode`); **ML** на ML.NET — multi-target `ml_tasks`, governor-блоки (2A/2B/2I/2P); **Discovery Engine** — pattern-mining → предложения (2F); **Дневник дома** — детерминированный NLG (2N); **Assistant-заглушка** (2H). WebApplication (Kestrel :8080, метрики :9090).
- **[PluginSupervisor](../src/Services/Domovoy.PluginSupervisor/)** — обнаружение `plugin.json`, resource-aware гейтинг, запуск плагинов отдельными процессами, рестарт с backoff (1C); один живой плагин — **Commute** (2M.1, traffic-aware ETA).

**Шлюзы (2):**
- **[DbGateway](../src/Gateway/Domovoy.DbGateway/)** — Minimal-API + MongoDB; `EventInterceptor` пишет read-модель + append-only feature store; авторитет персиста зон/режима/правил/блоков/ML/ролей/дашбордов/дневника (~24 коллекции, см. [currentState.md](currentState.md)).
- **[ApiGateway](../src/Gateway/Domovoy.ApiGateway/)** — тонкие прокси-контроллеры к DbGateway / publish на шину; SignalR-хаб `/hub/devices`; JWT за флагом `JwtSettings:Enabled` (off).

> Полный список эндпоинтов и контроллеров — раздел «Шлюзы» в [currentState.md](currentState.md).
> **[НЕ закоммичено]** поверх этого: Эпик 3A (бэкапы, `BackupController`), Эпик 3B (сцены, `ScenesController`+
> action-тип `scene` в движке), system-restart (`SystemController`+`SystemControl.cs` в шине).

## Ключевые потоки данных

- **Discovery:** Adapter → `Envelope<DeviceDiscoveredV1>` (`domovoy.discovery`) → CapabilityDeviceManager (in-memory) **и** EventInterceptor (upsert `capability_devices`).
- **State:** Adapter → `Envelope<DeviceStateReportV1>` (`domovoy.state`) → CapabilityDeviceManager → `DeviceStateUpdatedEvent` → SignalR **и** EventInterceptor (merge state + дельта в `device_events` + телеметрия в `sensor_readings`).
- **Команды:** WebUI → `POST /api/device-control/{id}/set` → `Envelope<DeviceCommandV1>` (`domovoy.commands`) → владеющий адаптер → encode → MQTT.
- **Control block:** блок проецируется как **виртуальное capability-устройство** (discovery+state, `source=block:{id}`), читает capability других устройств через `DeviceRegistry` (blackboard), при изменении выхода шлёт `DeviceCommandV1` (актуация, 1D).
- **ML:** `MlTrainingService` тренирует ML.NET-модель из истории → `ml_models` (DbGateway); блок `ml_setpoint` грузит модель и эмитит уставку (safety-clamp).

Подробные потоки (online/offline, zigbee bridge) — раздел «Потоки данных» в [currentState.md](currentState.md).

## Технологический стек

| Слой | Технологии |
|---|---|
| Backend | .NET 9 · C# 12 · ASP.NET Core (Minimal API + Hosted Services) |
| Шина | RabbitMQ (AMQP 5672 + MQTT 1883) · `RabbitMQ.Client` 7 · `MQTTnet` 4.3 |
| БД | MongoDB (`MongoDB.Driver` 2.23) — состояние + time-series feature store |
| ML | `Microsoft.ML` 3.0.1 (SDCA-регрессия время→значение) |
| Реалтайм | SignalR (`@microsoft/signalr` 8) |
| Логи/метрики | Serilog (+ опц. Mongo-sink `ops_logs`) · prometheus-net · Prometheus (9090) |
| Frontend | React 18 · Vite · TypeScript · MUI 5 · recharts (React Flow убран вместе с `/flow`, НЕ закоммичено) |
| Hardware | Arduino (`DomovoyClient` v2, мультиустройственный) |

> Монолитного «service layer» из старых диаграмм (Device/Light/Sensor/Discovery, Ocelot, Grafana/Loki)
> **больше нет** — снят на Шаге 5 миграции. Если встретишь упоминания — это устаревшая документация.

## Статус компонентов (кратко)

| Компонент | Статус |
|---|---|
| Фаза 0 (фундамент: контракт, capability, зоны, event-log, auth-флаг) | ✅ закрыта |
| Фаза 1 (1A–1H: автоматизации, блоки, реплей, режимы, плагины) | ✅ функц. закрыта |
| Фаза 1.5 (живая верификация рантайма) | ✅ закрыта (data-path + offline-smoke + живой 3-оконный прогон) |
| Фаза 2 (интеллект: 2A–2Q, все эпики) | ✅ v1-done |
| Фаза 3 (продуктовая зрелость): 3A бэкапы, 3B сцены | 🚧 v1 реализован, **НЕ закоммичено**; 3C–3H — далее |

Полная статус-таблица — в [currentState.md](currentState.md) и [progress.md](progress.md).
</content>
